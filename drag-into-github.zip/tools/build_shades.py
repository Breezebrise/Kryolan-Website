"""Builds data/shades.json from the shade codes listed on kryolan.com.

Depth (1 very fair to 10 very deep), undertone (-2 cool/pink to +2 warm/golden)
and olive (0 to 2) are starting estimates from each code's family. Community
votes on the site override them. Run: python3 tools/build_shades.py
"""
import json, re, pathlib

SRC = "kryolan.com product pages, October 2026"

ULTRA_FOUNDATION = """RDS 7|DP|lavender veil|green neutralizer|grey green|pea green|YH|fair olive|RUF 1|ivory|NB|FS 38|SP. Med. Olive 2|yellow veil|amber|SP. Med. Olive 1|BS 4|TV white|DG|tan 5|pink highlight|fair|RN|1 W|2 W|DF|orange highlight|SPLO 1|olive|3 W|G 177|plantain|A 1|NB 1|SPLO|RUF 2|FS 42|alabaster|4 W|NB 2|OB 1|FS 45|BN|SPLO 3|toast|medium olive|ELO|OB 2|NB 3|5 W|RUF 4|LO|A 7|OB 3|A 2|deep olive|FS 36|FS 40|MO|SPLO 2|NB 4|RN 3|OB 4|Y 27|DO|RN 2|spice|nutmeg|ruddy beige|GT 1|SP. Med. Olive 3|D 32.1|B 1|green veil|molasses|101|cream|PT 1|PT 2|RUF 3|shibu|725 A|pink highlight 2|6 W|RDS 1|RB 3|suntan|8 W|PT 3|ODS 2|7 W|DBT|RB 4|ODS 1|9 W|RDS 2|10 W|RDS 3|V 25|12 W|malibu tan|D 33.1|RDS 4|cinnamon|cocoa|ODS 3|BS 2|mauby|11 W|GT 2|ODS 4|V 26|D 35.1|V 20|665 O|665 P|BS 1|V 23|BS 3|white|black"""

TV_PAINT_STICK = """FF 7|071|070 white|NB 2|NB|ELO|LO|406|alabaster|1 W|FS 47|ivory|NB 1|3 W|4 W|FS 45|OB 1|FS 38|FS 36|G 165|NB 3|OB 2|OB 3|DO|Y 27|303|TV white|5 W|6 W|8 W|FS 34|9 W|10 W|11 W|D 33.1|D 35.1|2 W|7 W|OB 4|D 32.1|12 W"""

ULTRA_FLUID = """020|ELO|LO|NB 4|DO|MO|fair olive|YH|DF|OB 2|6 W|OB 3|OB 4|ivory|NB|olive|shibu|NB 2|NB 3|BN|7 W|FS 36|RDS 2|9 W|8 W|10 W|malibu tan|11 W|GT 1|12 W|alabaster|2 W|OB 1|3 W|NB 1|G 177|4 W|5 W|SPLO|medium olive|deep olive|yellow veil|suntan|ODS 2|F 101|ODS 1|FS 38|fair|lila|010|002|RDS 1|RB 3|RDS 3|tan 5|GT 2|ODS 4|RDS 7|1 W|RDS 4|ODS 3|665 P|white|TV white"""

SUPRACOLOR_SKIN = """alabaster|ivory|fair|naturell|olive|medium olive|tan|suntone|NB|NB 1|NB 2|NB 3|NB 4|ELO|LO|DO|Y 27|G 177|OB 1|OB 2|OB 3|OB 4|OB 6|GT 1|GT 2|PT 1|1 W|2 W|3 W|4 W|5 W|6 W|7 W|8 W|9 W|10 W|11 W|12 W|FS 7|FS 9|FS 21|FS 22|FS 23|FS 24|FS 25|FS 26|FS 27|FS 28|FS 29|FS 31|FS 32|FS 33|FS 34|FS 35|FS 36|FS 38|FS 40|FS 41|FS 42|FS 45|FS 46|FS 47|FS 50|FS 51|FS 54|FS 55|FS 61|FS 64|FS 67|FS 69|N 1|N 2|N 3|N 5|N 6|N 9|N 10|N 12|V 4|V 5|V 10|V 12|V 13|V 14|V 15|V 16|V 17|V 18|V 19|V 20|V 22|V 23|EF 21|EF 22|EF 23|EF 24|EF 25|EF 26|EF 27|EF 28|EF 29|EF 30|EF 31|EF 80|EF 85|EF 86|D 32.1|D 32.2|D 32.3|D 32.4|D 33.1|D 33.2|D 35.1|death flesh|TV white"""

SUPRACOLOR_FX = """070|071|079|080|081|082|083|086|092|094|095|098|509|510|511|512|521|522|523|032|031|075|046|047|734|416|073|074|078|089|091|101|102|459|462|449|508|503|502|545|483|303|587|626|576|579|470|482|517|088|R 9|R 19|R 20|R 21|R 27|R 30|G 1|G 7|G 9|G 16|G 82|G 108|G 111|B 21|F 1|F 2|F 3|F 5|F 6|F 7|F 8|F 11|F 12|F 14|F 16|F 17|F 18|F 25|F 50|F 52|A 304|TK 2|K 1|mandarin blue|shading brown|shading red|purple green|youth red|silver blue|death grey|neutralizer|green|blue"""

DERMACOLOR = """D 0|D 00|D 1|D 1 ½|D 2|D 2 ½|D 3|D 3 ½|D 4|D 4 ½|D 5|D 5 ½|D 6|D 7|D 8|D 9|D 10|D 11|D 12|D 13|D 14|D 15|D 16|D 17|D 17 A|D 18|D 19|D 20|D 21|D 22|D 25|D 28 A|D 30|D 31|D 32|D 34|D 40|D 50|D 51|D 53|D 54|D 55|D 56|D 57|D 58|D 59|D 61|D 62|D 63|D 64|D 65|D 66|D 67|D 69|D 70|D 71|D 77|D 80|D 81|D 100|D 101|D 102|D 110|D 128|D 129|D 132|D 134|D 191|D 192|D 193|D 194|D 195|D 13/5|D 13/5 L|D 13/14|D 13/14 L|D 13/16|D 13/20|D 14/5|D 14/20|D 16/5|D 16/20|D 19/55|D 20/5|D 21/64|D 21/65|D 4/5|D 53/64|D 55/66|D 58/59|D 62/19|D 71/62|D 1 W|D 2 W|D 3 W|D 4 W|D 5 W|D 6 W|D 7 W|D 8 W|D 9 W|D 10 W|D 11 W|D NB|D NB 2|D NB 3|D NB 4|D OB 1|D OB 2|D OB 3|D ELO|D LO|D DO|D FD|D FD 1|D FS 38|D G 177|D G 178|D Y 27|D 1 C|D EF 80|D EF 85|D V 23|D J 1|D J 2|D J 4|D J 5|D J 6|D J 7|D J 8|D J 9|D DM 0|D DM ½|D DM 1|D DM 1 ¼|D DM 1 ½|D DM 1 ⅔|D DM 1 ¾|D DM 2|D DM 2 ⅛|D DM 2 ¼|D DM 2 ½|D DM 2 ⅔|D DM 2 ¾|D DM 3|D DM 4|D DM 4 ½|D DM 5|D DM 5 ¼|D DM 5 ½|D DM 5 ¾|D DM 6|D DM 7|D FF 7|D F 1|D F 2|D F 3|D F 17|D F 52|D R 21|D 070 white|D 071|D 079|D 080|D 089|D 095|D 041|D 043|D 305|D 375|D 406|D 508|D 509|D 510|D 511|D 512|D 517|D 545|D 546|D 701|D 707|D 732|D 733|D 734|D 1742|orange neutralizer|yellow neutralizer|green veil|lavender veil|red B"""

LINES = [
    ("tm", "Tinted Moisturizer", "TM 1|TM 2|TM 3|TM 4|TM 5", 1),
    ("uff", "Ultra Fluid Foundation", ULTRA_FLUID, 2),
    ("hd", "HD Micro Foundation Cream", "", 3),
    ("uf", "Ultra Foundation", ULTRA_FOUNDATION, 4),
    ("tvps", "TV Paint Stick", TV_PAINT_STICK, 4),
    ("sc", "Supracolor", SUPRACOLOR_SKIN, 5),
    ("scfx", "Supracolor Color & FX", SUPRACOLOR_FX, 5),
    ("dc", "Dermacolor Camouflage Creme", DERMACOLOR, 6),
]

NAMED = {  # name: (depth, undertone, olive, confidence)
    "white": (0.2, 0, 0, "med"), "tv white": (0.4, 0, 0, "med"), "alabaster": (1.2, -0.2, 0, "med"),
    "fair": (1.5, 0, 0, "med"), "ivory": (2, 1, 0, "med"), "cream": (2.2, 0.8, 0, "low"),
    "naturell": (3, 0.4, 0, "low"), "shibu": (3, 1.2, 0, "low"), "ruddy beige": (4, -1.2, 0, "low"),
    "fair olive": (3, 0.6, 1.4, "med"), "olive": (5, 0.6, 1.5, "med"), "medium olive": (5.5, 0.6, 1.5, "med"),
    "deep olive": (7.5, 0.6, 1.5, "med"), "amber": (6, 1.6, 0, "low"), "tan": (6.5, 1, 0, "low"),
    "tan 5": (6.5, 1, 0, "low"), "suntan": (6.5, 1.2, 0, "low"), "suntone": (6, 1.2, 0, "low"),
    "toast": (6.5, 0.8, 0, "low"), "malibu tan": (7, 1.2, 0, "low"), "spice": (7, 1.3, 0, "low"),
    "plantain": (7.5, 1.4, 0, "low"), "nutmeg": (8, 1, 0, "low"), "cinnamon": (8, 1.2, 0, "low"),
    "mauby": (9, 0.4, 0, "low"), "cocoa": (9, 0.6, 0, "low"), "molasses": (9.5, 0.4, 0, "low"),
    "black": (10, 0, 0, "med"), "death flesh": (3, -0.5, 1.8, "low"),
}
CORRECTORS = ("veil", "neutralizer", "highlight", "green", "lila", "lavender", "red b", "blue", "grey", "shading")

def estimate(code):
    raw = code.strip()
    c = re.sub(r"^D (?!\d)", "", raw) if raw.startswith("D ") else raw
    low = c.lower()
    if low in NAMED:
        d, u, o, conf = NAMED[low]; return dict(kind="skin", d=d, u=u, o=o, conf=conf)
    if any(k in low for k in CORRECTORS):
        return dict(kind="corrector")
    m = re.fullmatch(r"(\d+) ?W", c)
    if m:
        n = int(m.group(1)); return dict(kind="skin", d=round(1.5 + (n - 1) * 0.75, 2), u=1.2, o=0, conf="med")
    m = re.fullmatch(r"NB ?(\d?)", c)
    if m:
        n = int(m.group(1) or 0); return dict(kind="skin", d=[3.2, 2.6, 3.0, 3.8, 4.4][n], u=0, o=0, conf="med")
    m = re.fullmatch(r"OB ?(\d)", c)
    if m:
        n = int(m.group(1)); return dict(kind="skin", d=2.5 + n, u=0.5, o=1.1, conf="low")
    if c in ("ELO", "LO"):
        return dict(kind="skin", d=4 if c == "ELO" else 4.6, u=0.8, o=0.3, conf="med")
    m = re.fullmatch(r"(RDS|ODS|RB|BS|RUF|RN|GT|PT|SPLO|SP\. Med\. Olive) ?(\d?)", c)
    if m:
        fam, n = m.group(1), int(m.group(2) or 1)
        base = {"RDS": (7, -0.6, 0), "ODS": (7, 0.6, 1.2), "RB": (6.5, -0.4, 0), "BS": (7.5, 0.2, 0),
                "RUF": (4.5, -1, 0), "RN": (5, -0.6, 0), "GT": (6, 1, 0), "PT": (5, 1, 0),
                "SPLO": (5.5, 0.6, 1.2), "SP. Med. Olive": (5.5, 0.6, 1.5)}[fam]
        return dict(kind="skin", d=min(10, base[0] + (n - 1) * 0.7), u=base[1], o=base[2], conf="low")
    if re.fullmatch(r"TM ?\d|FS ?\d+|EF ?\d+|N ?\d+|V ?\d+|G 1\d\d|Y 27|DO|MO|BN|DF|DG|DP|DBT|YH|D ?3\d\.\d|DM.*|J \d|FD.*|\d+ ?C|\d+(/\d+)?( ?[½⅛¼⅔¾])?( [AL])?|.*/.*", c):
        return dict(kind="skin", d=5, u=0.4, o=0, conf="unknown")
    return dict(kind="fx")

out = {"source": SRC, "lines": []}
for lid, name, codes, cov in LINES:
    shades, seen = [], set()
    for code in [x.strip() for x in codes.split("|") if x.strip()]:
        if code.lower() in seen: continue
        seen.add(code.lower())
        e = estimate(code)
        if lid == "scfx" and e["kind"] == "skin": e = dict(kind="fx")
        shades.append({"code": code, **e})
    out["lines"].append({"id": lid, "name": name, "coverage": cov, "shades": shades})

p = pathlib.Path(__file__).resolve().parent.parent / "data" / "shades.json"
p.write_text(json.dumps(out, ensure_ascii=False, indent=1))
for l in out["lines"]:
    k = {}
    for s in l["shades"]: k[s.get("conf", s["kind"])] = k.get(s.get("conf", s["kind"]), 0) + 1
    print(l["name"], len(l["shades"]), k)
