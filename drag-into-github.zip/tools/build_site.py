"""Builds the static site into _site/.

Usage: python3 tools/build_site.py [--site-url https://example.github.io/kryolan-shade-lab]
The GitHub Actions workflow passes the real Pages URL so canonical links,
hreflang tags and the sitemap use absolute addresses.
"""
import argparse, html, json, math, re, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "_site"
ap = argparse.ArgumentParser(); ap.add_argument("--site-url", default="")
SITE = ap.parse_args().site_url.rstrip("/")
SITE = SITE + "/" if SITE else ""

I18N = json.loads((ROOT / "data/i18n.json").read_text())
DATA = json.loads((ROOT / "data/shades.json").read_text())
BRANDS = json.loads((ROOT / "data/brands.json").read_text())
WHEELS = json.loads((ROOT / "data/wheels.json").read_text())
SITECFG = json.loads((ROOT / "data/site.json").read_text())
VERIFY_NAMES = {"google": "google-site-verification", "bing": "msvalidate.01", "yandex": "yandex-verification", "baidu": "baidu-site-verification", "naver": "naver-site-verification"}
LANGS = [("en", ""), ("zh-Hans", "zh-hans/"), ("zh-Hant", "zh-hant/")]
OTHER = [("es", "Español"), ("pt", "Português"), ("fr", "Français"), ("de", "Deutsch"), ("it", "Italiano"), ("nl", "Nederlands"),
         ("pl", "Polski"), ("ru", "Русский"), ("uk", "Українська"), ("tr", "Türkçe"), ("ar", "العربية"), ("hi", "हिन्दी"),
         ("ja", "日本語"), ("ko", "한국어"), ("vi", "Tiếng Việt"), ("th", "ไทย"), ("id", "Bahasa Indonesia"), ("tl", "Filipino")]
EV = {"tm": "yes", "uff": "yes", "hd": "yes", "uf": "thin", "tvps": "maybe", "sc": "powder", "scfx": "no", "dc": "spot"}
EVKEY = {"yes": "ev_yes", "thin": "ev_thin", "maybe": "ev_maybe", "powder": "ev_powder", "spot": "ev_spot", "no": "ev_no"}
COV = {"tm": 1, "uff": 2, "hd": 3, "uf": 4, "tvps": 4, "sc": 5, "scfx": 5, "dc": 6}
e = lambda s: html.escape(str(s), quote=True)
clamp = lambda v, lo, hi: min(hi, max(lo, v))

# ---- mirrors assets/shared.js ----
def hexc(d, u, o):
    L, a, b = 92 - (d - 0.2) * 7.2, 11 + d * 0.5 - u * 2.4 - o * 3.2, 15 + u * 3.2 + d * 0.9 - o * 0.8
    y = (L + 16) / 116; x = a / 500 + y; z = y - b / 200
    f = lambda t: t ** 3 if t ** 3 > 0.008856 else (t - 16 / 116) / 7.787
    x, y, z = 0.95047 * f(x), f(y), 1.08883 * f(z)
    rgb = [x * 3.2406 + y * -1.5372 + z * -0.4986, x * -0.9689 + y * 1.8758 + z * 0.0415, x * 0.0557 + y * -0.204 + z * 1.057]
    def c(v):
        v = 1.055 * v ** (1 / 2.4) - 0.055 if v > 0.0031308 else 12.92 * v
        return round(clamp(v, 0, 1) * 255)
    return "#" + "".join(f"{c(v):02x}" for v in rgb)

def jsround(v): return math.floor(v + 0.5)
def depth_word(d, t): return t["depth_words"][clamp(jsround(d), 1, 10) - 1]
def under_key(u, o): return "u_olive" if o >= 1 else "u_warm" if u >= 1 else "u_warmneutral" if u >= 0.4 else "u_cool" if u <= -0.8 else "u_coolneutral" if u <= -0.3 else "u_neutral"
def brand_under(u, o): return "w_olive" if o >= 1 else "w_warm" if u >= 0.4 else "w_cool" if u <= -0.4 else "w_neutral"
def ranges(d, u, o, t):
    uw = t[brand_under(u, o)]; out = []
    mf = "NW" if u <= -0.4 else "NC"; m = clamp(jsround((10 + (d - 1) * 5.4) / 5) * 5, 10, 60)
    out.append(("MAC", "Studio Fix Fluid", " · ".join(f"{mf}{x}" for x in (m - 5, m, m + 5) if 10 <= x <= 60)))
    f = clamp(jsround((100 + (d - 1) * 44) / 10) * 10, 100, 490)
    out.append(("Fenty Beauty", "Pro Filt'r Soft Matte", f"{max(100, f - 20)}-{min(498, f + 20)}, {uw}"))
    L = "W" if (u >= 0.4 or o >= 1) else "C" if u <= -0.4 else "N"
    out.append(("Estee Lauder", "Double Wear", f"{clamp(jsround((d - 1) * 8 / 9), 0, 8)}{L}"))
    ML = "Y" if (u >= 0.4 or o >= 1) else "R" if u <= -0.4 else "N"
    out.append(("Make Up For Ever", "HD Skin", f"{clamp(1 + math.floor((d - 1) / 2.5), 1, 4)}{ML}"))
    b = clamp(jsround((110 + (d - 1) * 27) / 5) * 5, 110, 360)
    out.append(("Maybelline", "Fit Me Matte + Poreless", f"{b - 10}-{b + 10}"))
    out.append(("Mehron", "CreamBlend Stick", mehron(d, o)))
    out.append(("Ben Nye", "Matte HD Foundation", bennye(d, o)))
    return out
def mehron(d, o):
    if o >= 1: return ["Light Olive (OS2)", "Mid-Light Olive (OS4)", "Medium Olive (OS6)", "Mid-Dark Olive (OS8)", "Dark Olive (OS10)"][clamp(jsround((d - 2) / 1.75), 0, 4)]
    if d < 2: return "Alabaster (1B)"
    tiers = [("Light", "LT", 2, 3.5), ("Medium", "MED", 3.5, 5.5), ("Medium Dark", "MDK", 5.5, 7.75), ("Dark", "DK", 7.75, 10.01)]
    t = next((x for x in tiers if d < x[3]), tiers[3])
    k = clamp(math.floor((d - t[2]) / (t[3] - t[2]) * 5), 0, 4)
    return f"{t[0]} {k} ({t[1]}{k})"
def bennye(d, o):
    s = [(2, "NO-1 Pale Biscotte"), (3.5, "NO-3 Biscotte"), (5, "NO-5 Brulee"), (6, "NO-7 Soft Caramel"), (7, "NO-9 Tan Brulee")] if o >= 1 else \
        [(1.3, "CE-1 Fairest"), (2, "CE-2 Fair"), (3, "CE-3 Light Beige"), (4.2, "CE-5 Beige"), (5.4, "CE-7 Light Tan"), (6.5, "CE-9 Tan"), (7.5, "SA-5 Mocha"), (9, "SA-11 Espresso")]
    best = s[0]
    for x in s:
        if abs(x[0] - d) < abs(best[0] - d): best = x
    return best[1]
def wheel_for(d, u, o):
    fits = [w for w in WHEELS if w.get("d") and w["d"][0] <= d <= w["d"][1]]
    want = "olive" if o >= 1 else "warm" if u >= 0.4 else "neutral"
    fits.sort(key=lambda w: w.get("u") != want)
    return fits[0] if fits else None
def slug(s):
    s = s.lower()
    for k, v in (("½", "-half"), ("¼", "-quarter"), ("¾", "-3quarter"), ("⅔", "-2third"), ("⅛", "-eighth"), ("/", "-")): s = s.replace(k, v)
    return re.sub(r"[^a-z0-9]+", "-", s).strip("-")
def norm(line_id, code):
    c = re.sub(r"^D (?=\S)", "", code) if line_id == "dc" else code
    return re.sub(r"\s+", "", c.lower())

LINES = [l for l in DATA["lines"] if l["shades"]]
LINE_BY = {l["id"]: l for l in LINES}
for l in LINES:
    seen = set()
    for s in l["shades"]:
        s["slug"] = slug(s["code"]); assert s["slug"] and s["slug"] not in seen, (l["id"], s["code"]); seen.add(s["slug"])
BYNORM = {}
for l in LINES:
    for s in l["shades"]: BYNORM.setdefault(norm(l["id"], s["code"]), []).append((l, s))
ALL_BRANDS = sorted(set(BRANDS["community"]["pro"] + BRANDS["community"]["everyday"] + [b["name"] for b in BRANDS["encoded"]]), key=str.lower)
COMMUNITY_ONLY = [b for b in BRANDS["community"]["pro"] + BRANDS["community"]["everyday"] if b not in {x["name"] for x in BRANDS["encoded"]}]

PAGES = []  # (path) for sitemap

def pan(s, href=None):
    cls = "dot" + ("" if s["kind"] == "skin" and s.get("conf") != "unknown" else " unknown" if s["kind"] == "skin" else " " + s["kind"])
    style = f' style="background:{hexc(s["d"], s["u"], s["o"])}"' if s["kind"] == "skin" and s.get("conf") != "unknown" else ""
    tag = "a" if href else "span"
    return f'<{tag} class="pan"{f" href={chr(34)}{href}{chr(34)}" if href else ""}><span class="{cls}"{style}></span>{e(s["code"])}</{tag}>'

def page(lang, p, title, desc, body, kind="", jsonld=None, votes=False, crumbs=None):
    t = I18N[lang]; prefix = dict(LANGS)[lang]
    depth_all = (prefix + p).count("/"); root = "../" * depth_all or "./"
    langroot = "../" * p.count("/") or "./"
    nav = [("", t["nav_home"], "home"), ("shades/", t["nav_lines"], "shades"), ("wheels/", t["nav_wheels"], "wheels"), ("about/", t["nav_about"], "about")]
    navh = "".join(f'<a href="{langroot}{h}"{' aria-current="page"' if k == kind else ""}>{e(n)}</a>' for h, n, k in nav)
    langs = "".join(f'<a href="{root}{pf}{p}" hreflang="{L}" lang="{L}"{' aria-current="true"' if L == lang else ""}>{e(I18N[L]["label"])}</a>' for L, pf in LANGS)
    other = f'<select id="translate" aria-label="{e(t["translate_other"])}"><option value="">{e(t["translate_other"])}</option>' + "".join(f'<option value="{c}" lang="{c}">{e(n)}</option>' for c, n in OTHER) + "</select>"
    alt = ""
    verify = "".join(f'<meta name="{VERIFY_NAMES[k]}" content="{e(v)}">' for k, v in SITECFG["verify"].items() if v) if p == "" else ""
    if SITE:
        alt = f'<link rel="canonical" href="{SITE}{prefix}{p}">' + "".join(f'<link rel="alternate" hreflang="{L}" href="{SITE}{pf}{p}">' for L, pf in LANGS) + f'<link rel="alternate" hreflang="x-default" href="{SITE}{p}">'
        alt += f'<meta property="og:url" content="{SITE}{prefix}{p}">'
    ld = f'<script type="application/ld+json">{json.dumps(jsonld, ensure_ascii=False)}</script>' if jsonld else ""
    scripts = f'<script src="{root}assets/config.js"></script>' + (f'<script src="{root}assets/vendor/supabase.js"></script>' if votes else "") + f'<script src="{root}assets/shared.js"></script><script src="{root}assets/app.js"></script>'
    cr = ""
    if crumbs:
        cr = '<nav class="crumbs" aria-label="breadcrumb">' + " / ".join(f'<a href="{langroot}{h}">{e(n)}</a>' if h is not None else e(n) for n, h in crumbs) + "</nav>"
    doc = f"""<!doctype html>
<html lang="{t['html_lang']}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{e(title)}</title>
<meta name="description" content="{e(desc)}">
<meta property="og:type" content="website"><meta property="og:title" content="{e(title)}"><meta property="og:description" content="{e(desc)}"><meta property="og:site_name" content="{e(t['site_name'])}">
<meta name="twitter:card" content="summary">
<meta name="robots" content="index, follow, max-image-preview:large">
{verify}
{alt}
<link rel="icon" href="{root}assets/icon.svg" type="image/svg+xml">
<link rel="stylesheet" href="{root}assets/style.css">
{ld}
</head>
<body data-page="{kind}" data-root="{root}" data-langroot="{langroot}" data-lang="{lang}">
<div class="banner">{e(t['banner'])}</div>
<div class="top"><a class="brand" href="{langroot}">{e(t['site_name'])}</a><nav class="main" aria-label="main">{navh}</nav><div class="langs" aria-label="{e(t['lang_label'])}">{langs}{other}</div></div>
<main class="wrap">{cr}{body}</main>
<footer class="foot"><p>{e(t['footer'])}</p><p><a href="{langroot}about/">{e(t['nav_about'])}</a></p></footer>
<script type="application/json" id="i18n">{json.dumps(t, ensure_ascii=False)}</script>
{scripts}
</body>
</html>"""
    f = OUT / (prefix + p) / "index.html"; f.parent.mkdir(parents=True, exist_ok=True); f.write_text(doc)
    if lang == "en": PAGES.append(p)

def fill(tpl, **kw):
    for k, v in kw.items(): tpl = tpl.replace("{" + k + "}", str(v))
    return tpl

def shelf(t):
    rows = []
    for lid, name in [("tm", "Tinted Moisturizer"), ("uff", "Ultra Fluid Foundation"), ("hd", "HD Micro Foundation"), ("uf", "Ultra Foundation"),
                      ("tvps", "TV Paint Stick"), ("sc", "Supracolor"), ("scfx", "Supracolor Color & FX"), ("dc", "Dermacolor Camouflage Creme")]:
        meter = "".join(f'<i class="{"on" if n <= COV[lid] else ""}"></i>' for n in range(1, 7))
        rows.append(f'<article class="card" data-id="{lid}"><h3>{e(name)}</h3><div><div class="meta">{e(t["coverage"])}</div><div class="meter">{meter}</div></div>'
                    f'<span class="pill {EV[lid]}">{e(t[EVKEY[EV[lid]]])}</span><p>{e(t["f_" + lid])}</p>'
                    f'<div class="meta">{e(t["finish"])}: {e(t["f_" + lid + "_fin"])}<br>{e(t["best_for"])}: {e(t["f_" + lid + "_skin"])}</div></article>')
    return f'<section class="sec"><h2>{e(t["shelf_h"])}</h2><p class="lede">{e(t["shelf_lede"])}</p><div class="shelf">{"".join(rows)}</div></section>'

def vote_shade_box(t, line_id, code):
    opts = "".join(f'<option value="{n}">{n} · {e(t["depth_words"][n - 1])}</option>' for n in range(1, 11))
    uopts = "".join(f'<option value="{k}">{e(t["w_" + k])}</option>' for k in ("cool", "neutral", "warm", "olive"))
    return f'''<div class="panel" data-vote="shade" data-line="{e(line_id)}" data-code="{e(code)}"><h3>{e(t["consensus_h"])}</h3><div class="cons"><p class="meta">{e(t["no_consensus"])}</p></div>
<form class="shadevote"><div class="row2"><div><label for="vd-{e(slug(line_id + code))}">{e(t["vote_depth"])}</label><select id="vd-{e(slug(line_id + code))}" name="depth">{opts}</select></div>
<div><label for="vu-{e(slug(line_id + code))}">{e(t["vote_undertone"])}</label><select id="vu-{e(slug(line_id + code))}" name="undertone">{uopts}</select></div></div>
<p><button class="btn" type="submit">{e(t["cast_vote"])}</button></p></form><p class="status" role="status"></p></div>'''

def build():
    if OUT.exists(): shutil.rmtree(OUT)
    OUT.mkdir()
    shutil.copytree(ROOT / "assets", OUT / "assets"); (OUT / "data").mkdir()
    for n in ("shades.json", "wheels.json", "brands.json"): shutil.copy(ROOT / "data" / n, OUT / "data" / n)
    (OUT / ".nojekyll").write_text("")
    key = SITECFG["indexnow_key"]; (OUT / f"{key}.txt").write_text(key)
    datalist = '<datalist id="brands">' + "".join(f'<option value="{e(b)}">' for b in ALL_BRANDS) + "</datalist>"
    for lang, prefix in LANGS:
        t = I18N[lang]
        # Home
        body = f'''<header class="hero"><div class="eyebrow">Supracolor · TV Paint Stick · Ultra Foundation · Dermacolor</div><h1>{e(t["site_name"])}</h1><p class="lede">{e(t["home_lede"])}</p></header>
<section class="grid" aria-label="{e(t["matcher_h"])}"><div class="panel"><h2>{e(t["matcher_h"])}</h2>
<div><label for="line">{e(t["pick_line"])}</label><select id="line"></select></div>
<div><span class="lbl">{e(t["pick_shade"])}</span><div class="tray" id="tray" role="group" aria-label="{e(t["pick_shade"])}"></div></div>
<div><span class="lbl">{e(t["how_looks"])}</span>
<div class="slider"><input type="range" id="sDepth" min="-3" max="3" step="0.5" value="0" aria-label="{e(t["depth"])}"><div class="ends"><span>{e(t["lighter_on_me"])}</span><span>{e(t["same"])}</span><span>{e(t["darker_on_me"])}</span></div></div>
<div class="slider"><input type="range" id="sUnder" min="-2" max="2" step="0.5" value="0" aria-label="{e(t["undertone"])}"><div class="ends"><span>{e(t["pinker_on_me"])}</span><span>{e(t["same"])}</span><span>{e(t["yellower_on_me"])}</span></div></div>
<div class="slider"><input type="range" id="sOlive" min="0" max="2" step="0.5" value="0" aria-label="{e(t["ashy_on_me"])}"><div class="ends"><span>{e(t["not_ashy"])}</span><span>{e(t["ashy_on_me"])}</span></div></div></div>
<div class="compare"><div class="chip" id="chipChart"></div><div class="chip" id="chipReal"></div></div><p class="note">{e(t["screen_note"])}</p></div>
<div class="panel" aria-live="polite"><h2>{e(t["needs_h"])}</h2><span class="badge" id="rConf"></span>
<dl class="kv"><dt>{e(t["depth"])}</dt><dd id="rDepth"></dd><dt>{e(t["undertone"])}</dt><dd id="rUnder"></dd><dt>{e(t["formula"])}</dt><dd id="rLine"></dd></dl>
<div><span class="lbl">{e(t["start_here"])}</span><div class="tablewrap"><table class="ranges"><tbody id="rBrands"></tbody></table></div><p class="note">{e(t["ranges_note"])}</p></div>
<div><span class="lbl">{e(t["next_pan"])}</span><div class="tags" id="rNext"></div></div>
<div><span class="lbl">{e(t["wheel_pick"])}</span><div class="tags" id="rWheel"></div></div>
<div><span class="lbl">{e(t["fix_h"])}</span><p id="rFix"></p></div>
<p><a class="btn" id="rPage" href="shades/">{e(t["open_shade_page"])}</a></p></div></section>
{shelf(t)}
<section class="verdict"><h2>{e(t["supra_h"])}</h2><p>{e(t["supra_p1"])}</p><p>{e(t["supra_p2"])}</p><p>{e(t["supra_p3"])}</p></section>'''
        page(lang, "", t["home_title"], t["home_desc"], body, "home",
             {"@context": "https://schema.org", "@type": "WebSite", "name": t["site_name"], "inLanguage": t["html_lang"], "description": t["home_desc"], **({"url": SITE + prefix} if SITE else {})})
        # All lines
        cards = "".join(f'<a class="card" href="{l["id"]}/"><h3>{e(l["name"])}</h3><p class="meta">{len(l["shades"])} {e(t["shades_n"])}</p><p>{e(t["f_" + l["id"]])}</p></a>' for l in LINES)
        page(lang, "shades/", t["lines_title"], t["lines_desc"], f'<header class="hero"><h1>{e(t["lines_title"])}</h1><p class="lede">{e(t["conf_note"])}</p></header><div class="linegrid">{cards}</div>', "shades",
             crumbs=[(t["nav_home"], ""), (t["nav_lines"], None)])
        for l in LINES:
            lname = l["name"]
            tray = "".join(pan(s, f'{s["slug"]}/') for s in l["shades"])
            body = f'<header class="hero"><h1>Kryolan {e(lname)}</h1><p class="lede">{e(t["f_" + l["id"]])}</p><span class="pill {EV[l["id"]]}">{e(t[EVKEY[EV[l["id"]]]])}</span></header><div class="tray full">{tray}</div><p class="note">{e(t["conf_note"])}</p>'
            page(lang, f'shades/{l["id"]}/', fill(t["line_title"], line=lname), fill(t["line_desc"], line=lname, n=len(l["shades"])), body, "shades",
                 crumbs=[(t["nav_home"], ""), (t["nav_lines"], "shades/"), (lname, None)])
            skins = [s for s in l["shades"] if s["kind"] == "skin" and s["conf"] != "unknown"]
            for s in l["shades"]:
                p = f'shades/{l["id"]}/{s["slug"]}/'; code = s["code"]
                known = s["kind"] == "skin" and s["conf"] != "unknown"
                if known:
                    dw, uw = depth_word(s["d"], t), t[under_key(s["u"], s["o"])]
                    est = f'<dl class="kv"><dt>{e(t["depth"])}</dt><dd>{e(dw)} ({s["d"]:.1f} / 10)</dd><dt>{e(t["undertone"])}</dt><dd>{e(uw)}</dd><dt>{e(t["formula"])}</dt><dd>{e(lname)}</dd></dl><span class="badge {s["conf"]}">{e(t["conf_" + s["conf"]])}</span><p class="note">{e(t["conf_note"])}</p>'
                    rows = "".join(f'<tr><td>{e(b)}<br><span class="meta">{e(pr)}</span></td><td class="mono">{e(tx)}</td></tr>' for b, pr, tx in ranges(s["d"], s["u"], s["o"], t))
                    w = wheel_for(s["d"], s["u"], s["o"])
                    rng = f'<section class="sec"><h2>{e(t["est_ranges_h"])}</h2><div class="tablewrap"><table class="ranges"><tbody>{rows}</tbody></table></div><p class="note">{e(t["ranges_note"])}</p><p class="note">{e(t["community_only"])}: {e(", ".join(COMMUNITY_ONLY))}.</p><p class="note">{e(t["findation_note"])} <a href="https://www.findation.com/" rel="noopener">Findation.com</a></p>'
                    if w: rng += f'<p><span class="lbl">{e(t["wheel_pick"])}</span><a class="tag" href="{"../" * 3}wheels/#{w["id"]}">{e(w["name"])}</a></p>'
                    rng += "</section>"
                    desc = fill(t["shade_desc"], line=lname, code=code, depth=dw, under=uw)
                    near = sorted((x for x in skins if x is not s), key=lambda x: math.hypot(x["d"] - s["d"], (x["u"] - s["u"]) * 1.2, x["o"] - s["o"]))[:6]
                    nearh = f'<section class="sec"><h2>{e(t["nearest_h"])}</h2><div class="tray">{"".join(pan(x, "../" + x["slug"] + "/") for x in near)}</div></section>' if near else ""
                else:
                    note = t["unknown_shade"] if s["kind"] == "skin" else t["fx_note"] if s["kind"] == "fx" else t["corrector_note"]
                    label = t["conf_unknown"] if s["kind"] == "skin" else t["kind_" + s["kind"]]
                    est = f'<span class="badge unknown">{e(label)}</span><p>{e(note)}</p>'
                    rng, nearh = "", ""
                    desc = fill(t["shade_desc_fx"], line=lname, code=code)
                others = [(ol, os_) for ol, os_ in BYNORM.get(norm(l["id"], code), []) if ol is not l]
                links = "".join('<a class="tag" href="../../{}/{}/">{} {}</a>'.format(ol["id"], os_["slug"], e(ol["name"]), e(os_["code"])) for ol, os_ in others)
                sameh = f'<section class="sec"><h2>{e(t["same_code_h"])}</h2><div class="tags">{links}</div></section>' if others else ""
                dupe = f'''<section class="panel" data-vote="dupes" data-line="{e(l["id"])}" data-code="{e(code)}"><h2>{e(t["dupes_h"])}</h2><p class="note">{e(t["dupes_lede"])}</p><div class="dupes"></div>
<form class="adddupe"><h3>{e(t["add_dupe"])}</h3><div class="row3"><div><label for="db">{e(t["brand"])}</label><input type="text" id="db" name="brand" list="brands" maxlength="60" required></div>
<div><label for="dp">{e(t["product"])}</label><input type="text" id="dp" name="product" maxlength="80"></div><div><label for="ds">{e(t["shade_name"])}</label><input type="text" id="ds" name="shade" maxlength="60" list="brandshades" required><datalist id="brandshades"></datalist></div></div>{datalist}
<p><button class="btn" type="submit">{e(t["submit"])}</button></p></form><p class="status" role="status"></p></section>'''
                rep = f'<section class="panel" data-vote="report" data-line="{e(l["id"])}" data-code="{e(code)}"><h3>{e(t["report_h"])}</h3><form><label for="rn" class="lbl">{e(t["report_h"])}</label><input type="text" id="rn" name="note" maxlength="500" placeholder="{e(t["report_ph"])}"><p><button class="btn ghost" type="submit">{e(t["report_btn"])}</button></p></form><p class="status" role="status"></p></section>'
                chip = f'<div class="chip" style="background:{hexc(s["d"], s["u"], s["o"])}">{e(code)} · {e(t["chart_estimate"])}</div>' if known else ""
                body = f'''<header class="hero"><div class="eyebrow">Kryolan {e(lname)}</div><h1>{e(lname)} {e(code)}</h1></header>
<section class="grid"><div class="panel">{chip}{est}</div>{vote_shade_box(t, l["id"], code) if s["kind"] == "skin" else ""}</section>
{rng}{dupe}{sameh}{nearh}{rep}<p><a href="../">{e(fill(t["back_line"], line=lname))}</a></p>'''
                crumbs = [(t["nav_home"], ""), (t["nav_lines"], "shades/"), (lname, f'shades/{l["id"]}/'), (code, None)]
                ld = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
                    {"@type": "ListItem", "position": i + 1, "name": n, **({"item": SITE + prefix + h} if SITE and h is not None else {})} for i, (n, h) in enumerate(crumbs)]}
                page(lang, p, fill(t["shade_title"], line=lname, code=code), desc, body, "shades", ld, votes=True, crumbs=crumbs)
        # Wheels
        cards = []
        for w in WHEELS:
            tags = "".join(f'<span class="tag">{e(c)}</span>' for c in w["contents"])
            cards.append(f'<article class="card" id="{w["id"]}"><h3>{e(w["name"])}</h3><div><span class="lbl">{e(t["wheel_best_for"])}</span><p>{e(t[w["best"]])}</p></div><div><span class="lbl">{e(t["wheel_contains"])}</span><div class="tags">{tags}</div></div>{vote_shade_box(t, "wheel", w["id"])}</article>')
        body = f'<header class="hero"><h1>{e(t["wheels_h"])}</h1><p class="lede">{e(t["wheels_lede"])}</p><p class="note">{e(t["corrector_note"])}</p></header><div class="shelf">{"".join(cards)}</div>'
        page(lang, "wheels/", t["wheels_title"], t["wheels_desc"], body, "wheels", votes=True, crumbs=[(t["nav_home"], ""), (t["nav_wheels"], None)])
        # About
        body = f'<article class="prose"><h1>{e(t["about_h"])}</h1><p>{e(t["about_p1"])}</p><p>{e(t["about_p2"])}</p><p>{e(t["about_p3"])}</p><p>{e(t["about_p4"])}</p><p class="meta">{e(DATA["source"])}</p></article>'
        page(lang, "about/", t["about_title"], t["about_desc"], body, "about", crumbs=[(t["nav_home"], ""), (t["nav_about"], None)])
    # 404, robots, sitemap
    t = I18N["en"]
    (OUT / "404.html").write_text(f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Page not found · {e(t["site_name"])}</title><meta name="robots" content="noindex"><style>body{{font-family:system-ui,sans-serif;max-width:40rem;margin:4rem auto;padding:0 16px}}</style></head><body><h1>Page not found</h1><p><a href="{SITE or "/"}">{e(t["site_name"])}</a></p></body></html>')
    (OUT / "robots.txt").write_text("User-agent: *\nAllow: /\n" + (f"Sitemap: {SITE}sitemap.xml\n" if SITE else ""))
    if SITE:
        urls = []
        for p in PAGES:
            alts = "".join(f'<xhtml:link rel="alternate" hreflang="{L}" href="{SITE}{pf}{p}"/>' for L, pf in LANGS)
            for L, pf in LANGS: urls.append(f"<url><loc>{e(SITE + pf + p)}</loc>{alts}</url>")
        (OUT / "sitemap.xml").write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">\n' + "\n".join(urls) + "\n</urlset>\n")
    print(f"Built {len(PAGES) * len(LANGS)} pages into {OUT}")

build()
