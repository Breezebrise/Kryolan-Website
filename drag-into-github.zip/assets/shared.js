// Pure helpers shared by every page. tools/build_site.py mirrors estimate() and ranges() for the static pages.
(function (g) {
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
  const r5 = v => Math.round(v / 5) * 5, r10 = v => Math.round(v / 10) * 10;

  function lab2hex(L, a, b) {
    let y = (L + 16) / 116, x = a / 500 + y, z = y - b / 200;
    const f = t => (t ** 3 > 0.008856 ? t ** 3 : (t - 16 / 116) / 7.787);
    x = 0.95047 * f(x); y = f(y); z = 1.08883 * f(z);
    const rgb = [x * 3.2406 + y * -1.5372 + z * -0.4986, x * -0.9689 + y * 1.8758 + z * 0.0415, x * 0.0557 + y * -0.204 + z * 1.057];
    return "#" + rgb.map(v => {
      v = v > 0.0031308 ? 1.055 * Math.pow(v, 1 / 2.4) - 0.055 : 12.92 * v;
      return Math.round(clamp(v, 0, 1) * 255).toString(16).padStart(2, "0");
    }).join("");
  }
  // depth 0.2 (white) to 10 (very deep), undertone -2 cool to +2 warm, olive 0 to 2
  const hex = (d, u, o) => lab2hex(92 - (d - 0.2) * 7.2, 11 + d * 0.5 - u * 2.4 - o * 3.2, 15 + u * 3.2 + d * 0.9 - o * 0.8);

  const depthWord = (d, t) => t.depth_words[clamp(Math.round(d), 1, 10) - 1];
  const underKey = (u, o) => (o >= 1 ? "u_olive" : u >= 1 ? "u_warm" : u >= 0.4 ? "u_warmneutral" : u <= -0.8 ? "u_cool" : u <= -0.3 ? "u_coolneutral" : "u_neutral");
  const brandUnder = (u, o) => (o >= 1 ? "w_olive" : u >= 0.4 ? "w_warm" : u <= -0.4 ? "w_cool" : "w_neutral");

  // Starting ranges for brands whose shade names encode depth and undertone.
  function ranges(n, t) {
    const out = [], uw = t[brandUnder(n.u, n.o)];
    const mf = n.u <= -0.4 ? "NW" : "NC", m = clamp(r5(10 + (n.d - 1) * 5.4), 10, 60);
    out.push({ brand: "MAC", product: "Studio Fix Fluid", text: [m - 5, m, m + 5].filter(x => x >= 10 && x <= 60).map(x => mf + x).join(" · ") });
    const f = clamp(r10(100 + (n.d - 1) * 44), 100, 490);
    out.push({ brand: "Fenty Beauty", product: "Pro Filt'r Soft Matte", text: `${Math.max(100, f - 20)}-${Math.min(498, f + 20)}, ${uw}` });
    const L = n.u >= 0.4 || n.o >= 1 ? "W" : n.u <= -0.4 ? "C" : "N";
    out.push({ brand: "Estee Lauder", product: "Double Wear", text: `${clamp(Math.round((n.d - 1) * 8 / 9), 0, 8)}${L}` });
    const ML = n.u >= 0.4 || n.o >= 1 ? "Y" : n.u <= -0.4 ? "R" : "N";
    out.push({ brand: "Make Up For Ever", product: "HD Skin", text: `${clamp(1 + Math.floor((n.d - 1) / 2.5), 1, 4)}${ML}` });
    const b = clamp(r5(110 + (n.d - 1) * 27), 110, 360);
    out.push({ brand: "Maybelline", product: "Fit Me Matte + Poreless", text: `${b - 10}-${b + 10}` });
    out.push({ brand: "Mehron", product: "CreamBlend Stick", text: mehron(n) });
    out.push({ brand: "Ben Nye", product: "Matte HD Foundation", text: bennye(n) });
    return out;
  }
  // Mehron and Ben Nye shade names spell out depth, so these come from the names themselves.
  function mehron(n) {
    if (n.o >= 1) return ["Light Olive (OS2)", "Mid-Light Olive (OS4)", "Medium Olive (OS6)", "Mid-Dark Olive (OS8)", "Dark Olive (OS10)"][clamp(Math.round((n.d - 2) / 1.75), 0, 4)];
    if (n.d < 2) return "Alabaster (1B)";
    const tiers = [["Light", "LT", 2, 3.5], ["Medium", "MED", 3.5, 5.5], ["Medium Dark", "MDK", 5.5, 7.75], ["Dark", "DK", 7.75, 10.01]];
    const t = tiers.find(x => n.d < x[3]) || tiers[3];
    const k = clamp(Math.floor(((n.d - t[2]) / (t[3] - t[2])) * 5), 0, 4);
    return `${t[0]} ${k} (${t[1]}${k})`;
  }
  function bennye(n) {
    const set = n.o >= 1 ? [[2, "NO-1 Pale Biscotte"], [3.5, "NO-3 Biscotte"], [5, "NO-5 Brulee"], [6, "NO-7 Soft Caramel"], [7, "NO-9 Tan Brulee"]]
      : [[1.3, "CE-1 Fairest"], [2, "CE-2 Fair"], [3, "CE-3 Light Beige"], [4.2, "CE-5 Beige"], [5.4, "CE-7 Light Tan"], [6.5, "CE-9 Tan"], [7.5, "SA-5 Mocha"], [9, "SA-11 Espresso"]];
    return set.reduce((a, b) => (Math.abs(b[0] - n.d) < Math.abs(a[0] - n.d) ? b : a))[1];
  }

  function wheelFor(n, wheels) {
    const fits = wheels.filter(w => w.d && n.d >= w.d[0] && n.d <= w.d[1]);
    const want = n.o >= 1 ? "olive" : n.u >= 0.4 ? "warm" : "neutral";
    fits.sort((a, b) => (b.u === want) - (a.u === want));
    return fits[0] || null;
  }

  const slug = s => s.toLowerCase().replace(/½/g, "-half").replace(/¼/g, "-quarter").replace(/¾/g, "-3quarter").replace(/⅔/g, "-2third").replace(/⅛/g, "-eighth").replace(/\//g, "-").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");

  g.KSL = { clamp, hex, depthWord, underKey, brandUnder, ranges, wheelFor, slug };
})(window);
