(function () {
  const $ = id => document.getElementById(id);
  const T = JSON.parse(document.getElementById("i18n").textContent);
  const B = document.body.dataset, ROOT = B.root || "./", LANGROOT = B.langroot || "./";
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  // Other languages: hand off to Google Translate. Built-in browser translation also works.
  const tr = $("translate");
  if (tr) tr.addEventListener("change", () => {
    if (!tr.value) return;
    location.href = "https://translate.google.com/translate?sl=auto&tl=" + tr.value + "&u=" + encodeURIComponent(location.href);
  });

  /* ---------- Home: shade matcher ---------- */
  async function matcher() {
    const [data, wheels] = await Promise.all([fetch(ROOT + "data/shades.json").then(r => r.json()), fetch(ROOT + "data/wheels.json").then(r => r.json())]);
    const lines = data.lines.filter(l => l.shades.some(s => s.kind === "skin"));
    let line = lines.find(l => l.id === "sc") || lines[0];
    let cur = line.shades.find(s => s.code === "alabaster") || line.shades[0];
    try { const saved = JSON.parse(localStorage.getItem("ksl-last") || "null"); if (saved) { const l = lines.find(x => x.id === saved.l); const s = l && l.shades.find(x => x.code === saved.c); if (s) { line = l; cur = s; } } } catch (e) {}
    $("line").innerHTML = lines.map(l => `<option value="${l.id}"${l === line ? " selected" : ""}>${esc(l.name)}</option>`).join("");
    const skin = () => line.shades.filter(s => s.kind === "skin");
    function tray() {
      $("tray").innerHTML = skin().map((s, i) => `<button type="button" class="pan" data-i="${i}" aria-pressed="${s === cur}"><span class="dot${s.conf === "unknown" ? " unknown" : ""}" style="${s.conf === "unknown" ? "" : "background:" + KSL.hex(s.d, s.u, s.o)}"></span>${esc(s.code)}</button>`).join("");
      $("tray").querySelectorAll(".pan").forEach(b => (b.onclick = () => { cur = skin()[+b.dataset.i]; reset(); tray(); render(); }));
    }
    const reset = () => ["sDepth", "sUnder", "sOlive"].forEach(id => ($(id).value = 0));
    function render() {
      try { localStorage.setItem("ksl-last", JSON.stringify({ l: line.id, c: cur.code })); } catch (e) {}
      const dv = +$("sDepth").value, uv = +$("sUnder").value, ov = +$("sOlive").value;
      const seen = { d: KSL.clamp(cur.d + dv, 0.2, 10), u: KSL.clamp(cur.u + uv, -2, 2), o: KSL.clamp(cur.o - ov * 0.5, 0, 2) };
      const need = { d: KSL.clamp(cur.d - dv, 1, 10), u: KSL.clamp(cur.u - uv, -2, 2), o: KSL.clamp(cur.o - ov * 0.6, 0, 2) };
      $("chipChart").style.background = KSL.hex(cur.d, cur.u, cur.o); $("chipChart").textContent = cur.code + " · " + T.chart_estimate;
      $("chipReal").style.background = KSL.hex(seen.d, seen.u, seen.o); $("chipReal").textContent = cur.code + " · " + T.on_your_skin;
      $("rDepth").textContent = KSL.depthWord(need.d, T) + " (" + need.d.toFixed(1) + " / 10)";
      $("rUnder").textContent = T[KSL.underKey(need.u, need.o)];
      $("rLine").textContent = line.name;
      $("rConf").className = "badge " + cur.conf; $("rConf").textContent = T["conf_" + cur.conf];
      $("rBrands").innerHTML = KSL.ranges(need, T).map(r => `<tr><td>${esc(r.brand)}<br><span class="meta">${esc(r.product)}</span></td><td class="mono">${esc(r.text)}</td></tr>`).join("");
      const same = Math.hypot(cur.d - need.d, cur.u - need.u, cur.o - need.o) < 0.4;
      const near = skin().filter(s => s !== cur && s.conf !== "unknown").map(s => ({ s, k: Math.hypot(s.d - need.d, (s.u - need.u) * 1.2, s.o - need.o) })).sort((a, b) => a.k - b.k).slice(0, 3);
      $("rNext").innerHTML = same ? `<span class="tag">${esc(T.keep_shade)}</span>` : near.map(x => `<a class="tag" href="${LANGROOT}shades/${line.id}/${KSL.slug(x.s.code)}/">${esc(x.s.code)}</a>`).join("");
      const fx = [];
      if (dv > 0) fx.push(T.fix_lighter); if (dv < 0) fx.push(T.fix_darker);
      if (uv > 0) fx.push(T.fix_orange); if (uv < 0) fx.push(T.fix_pink); if (ov > 0) fx.push(T.fix_ashy);
      $("rFix").textContent = fx.length ? fx.join(" ") : T.fix_none;
      const w = KSL.wheelFor(need, wheels);
      $("rWheel").innerHTML = w ? `<a class="tag" href="${LANGROOT}wheels/#${w.id}">${esc(w.name)}</a>` : `<a class="tag" href="${LANGROOT}wheels/">${esc(T.nav_wheels)}</a>`;
      $("rPage").href = `${LANGROOT}shades/${line.id}/${KSL.slug(cur.code)}/`;
      document.querySelectorAll(".shelf .card").forEach(c => c.classList.toggle("mine", c.dataset.id === line.id));
    }
    $("line").onchange = () => { line = lines.find(l => l.id === $("line").value); cur = skin().find(s => s.code === cur.code) || skin()[0]; reset(); tray(); render(); };
    ["sDepth", "sUnder", "sOlive"].forEach(id => $(id).addEventListener("input", render));
    tray(); render();
  }

  /* ---------- Voting (Supabase) ---------- */
  const C = window.KSL_CONFIG || {};
  let db = null, me = null;
  async function connect() {
    if (db) return true;
    if (!C.supabaseUrl || !C.supabaseKey || !window.supabase) return false;
    try {
      db = window.supabase.createClient(C.supabaseUrl, C.supabaseKey, { auth: { persistSession: true } });
      let { data } = await db.auth.getSession();
      if (!data.session) { const r = await db.auth.signInAnonymously(); if (r.error) throw r.error; data = r.data; }
      me = (data.session || data).user.id;
      return true;
    } catch (e) { console.error(e); db = null; return "fail"; }
  }
  const setStatus = (el, msg) => { if (el) el.textContent = msg; };

  async function consensus(box) {
    const line = box.dataset.line, code = box.dataset.code, out = box.querySelector(".cons"), st = box.querySelector(".status");
    const form = box.querySelector("form.shadevote");
    const ok = await connect();
    if (ok !== true) { setStatus(st, ok === "fail" ? T.signin_fail : T.voting_off); form && form.querySelectorAll("select,button").forEach(e => (e.disabled = true)); return; }
    async function load() {
      const { data } = await db.from("shade_consensus").select("*").eq("line_id", line).eq("shade_code", code).maybeSingle();
      out.innerHTML = data && data.n ? `<dl class="kv"><dt>${esc(T.depth)}</dt><dd>${esc(KSL.depthWord(+data.depth, T))} (${data.depth} / 10)</dd><dt>${esc(T.undertone)}</dt><dd>${esc(T["w_" + data.undertone] || data.undertone)}</dd></dl><p class="meta">${data.n} ${esc(T.votes_n)}</p>` : `<p class="meta">${esc(T.no_consensus)}</p>`;
      const mine = await db.from("shade_votes").select("depth,undertone").eq("line_id", line).eq("shade_code", code).eq("user_id", me).maybeSingle();
      if (mine.data && form) { form.depth.value = mine.data.depth; form.undertone.value = mine.data.undertone; }
    }
    if (form) form.onsubmit = async ev => {
      ev.preventDefault();
      const { error } = await db.from("shade_votes").upsert({ line_id: line, shade_code: code, user_id: me, depth: +form.depth.value, undertone: form.undertone.value }, { onConflict: "line_id,shade_code,user_id" });
      setStatus(st, error ? T.error_generic : T.thanks_vote); if (!error) load();
    };
    load();
  }

  async function dupes(box) {
    const line = box.dataset.line, code = box.dataset.code, list = box.querySelector(".dupes"), st = box.querySelector(".status"), form = box.querySelector("form.adddupe");
    const ok = await connect();
    if (ok !== true) { setStatus(st, ok === "fail" ? T.signin_fail : T.voting_off); form.querySelectorAll("input,select,button").forEach(e => (e.disabled = true)); list.innerHTML = `<p class="meta">${esc(T.no_dupes_yet)}</p>`; return; }
    async function load() {
      const [{ data: rows }, { data: mine }] = await Promise.all([
        db.from("dupe_scores").select("*").eq("line_id", line).eq("shade_code", code).order("net", { ascending: false }).limit(50),
        db.from("dupe_votes").select("dupe_id,value").eq("user_id", me)]);
      const mv = new Map((mine || []).map(v => [v.dupe_id, v.value]));
      list.innerHTML = rows && rows.length ? rows.map(d => {
        const conf = d.up >= 3 && d.net > 0, v = mv.get(d.id);
        return `<div class="dupe"><div><b>${esc(d.brand)} ${esc(d.product)}</b> <span class="mono">${esc(d.shade)}</span>${conf ? ` <span class="badge med">${esc(T.confirmed)}</span>` : ""}<small>+${d.up} / -${d.down}</small></div>
        <div class="votebtns"><button type="button" data-id="${d.id}" data-v="1" aria-pressed="${v === 1}">${esc(T.vote_up)}</button><button type="button" data-id="${d.id}" data-v="-1" aria-pressed="${v === -1}">${esc(T.vote_down)}</button></div></div>`;
      }).join("") : `<p class="meta">${esc(T.no_dupes_yet)}</p>`;
      list.querySelectorAll(".votebtns button").forEach(b => (b.onclick = () => vote(+b.dataset.id, +b.dataset.v)));
    }
    async function vote(id, v) {
      const { error } = await db.from("dupe_votes").upsert({ dupe_id: id, user_id: me, value: v }, { onConflict: "dupe_id,user_id" });
      setStatus(st, error ? T.error_generic : T.thanks_vote); load();
    }
    fetch(ROOT + "data/brands.json").then(r => r.json()).then(cat => {
      const dl = box.querySelector("#brandshades"), fill = () => {
        const c = cat.catalog[Object.keys(cat.catalog).find(k => k.toLowerCase() === form.brand.value.trim().toLowerCase())];
        dl.innerHTML = c ? c.shades.map(x => `<option value="${esc(x)}">`).join("") : "";
        if (c && !form.product.value) form.product.value = c.product;
      };
      form.brand.addEventListener("change", fill); form.brand.addEventListener("input", fill);
    }).catch(() => {});
    form.onsubmit = async ev => {
      ev.preventDefault();
      const row = { line_id: line, shade_code: code, brand: form.brand.value.trim(), product: form.product.value.trim(), shade: form.shade.value.trim() };
      if (!row.brand || !row.shade) return;
      let { data, error } = await db.from("dupes").insert(row).select("id").single();
      if (error && error.code === "23505") {
        const ex = await db.from("dupes").select("id").eq("line_id", line).eq("shade_code", code).ilike("brand", row.brand).ilike("product", row.product).ilike("shade", row.shade).maybeSingle();
        data = ex.data; error = null;
      }
      if (error || !data) { setStatus(st, T.error_generic); return; }
      await db.from("dupe_votes").upsert({ dupe_id: data.id, user_id: me, value: 1 }, { onConflict: "dupe_id,user_id" });
      form.product.value = ""; form.shade.value = ""; setStatus(st, T.thanks_dupe); load();
    };
    load();
  }

  async function report(box) {
    const form = box.querySelector("form"), st = box.querySelector(".status");
    form.onsubmit = async ev => {
      ev.preventDefault();
      const ok = await connect();
      if (ok !== true) { setStatus(st, ok === "fail" ? T.signin_fail : T.voting_off); return; }
      const note = form.note.value.trim(); if (!note) return;
      const { error } = await db.from("shade_reports").insert({ line_id: box.dataset.line, shade_code: box.dataset.code, note });
      setStatus(st, error ? T.error_generic : T.report_ok); if (!error) form.note.value = "";
    };
  }

  if (B.page === "home") matcher();
  document.querySelectorAll("[data-vote='shade']").forEach(consensus);
  document.querySelectorAll("[data-vote='dupes']").forEach(dupes);
  document.querySelectorAll("[data-vote='report']").forEach(report);
})();
