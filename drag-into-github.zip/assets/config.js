// Voting database settings. Leave both empty and the site still works, with voting switched off.
// Fill them in from Supabase: Project Settings > API (Project URL and the anon public key).
window.KSL_CONFIG = {
  supabaseUrl: "",
  supabaseKey: ""
};
