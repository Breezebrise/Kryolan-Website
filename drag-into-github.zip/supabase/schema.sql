-- Kryolan Shade Lab voting database.
-- Run once in Supabase: SQL Editor > New query > paste this file > Run.
-- Then turn on anonymous sign-ins (Authentication > Sign In / Providers > Allow anonymous sign-ins).

create table if not exists public.dupes (
  id bigint generated always as identity primary key,
  line_id text not null check (char_length(line_id) between 1 and 20),
  shade_code text not null check (char_length(shade_code) between 1 and 40),
  brand text not null check (char_length(brand) between 1 and 60),
  product text not null default '' check (char_length(product) <= 80),
  shade text not null check (char_length(shade) between 1 and 60),
  created_by uuid not null default auth.uid() references auth.users on delete cascade,
  created_at timestamptz not null default now()
);
create unique index if not exists dupes_unique
  on public.dupes (line_id, shade_code, lower(brand), lower(product), lower(shade));

create table if not exists public.dupe_votes (
  dupe_id bigint not null references public.dupes on delete cascade,
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  value smallint not null check (value in (-1, 1)),
  created_at timestamptz not null default now(),
  primary key (dupe_id, user_id)
);

-- Owner votes on a shade's real depth and undertone. Wheels use line_id 'wheel'.
create table if not exists public.shade_votes (
  line_id text not null check (char_length(line_id) between 1 and 20),
  shade_code text not null check (char_length(shade_code) between 1 and 40),
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  depth smallint not null check (depth between 1 and 10),
  undertone text not null check (undertone in ('cool', 'neutral', 'warm', 'olive')),
  created_at timestamptz not null default now(),
  primary key (line_id, shade_code, user_id)
);

create table if not exists public.shade_reports (
  id bigint generated always as identity primary key,
  line_id text not null check (char_length(line_id) between 1 and 20),
  shade_code text not null check (char_length(shade_code) between 1 and 40),
  note text not null check (char_length(note) between 1 and 500),
  created_by uuid not null default auth.uid() references auth.users on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.dupes enable row level security;
alter table public.dupe_votes enable row level security;
alter table public.shade_votes enable row level security;
alter table public.shade_reports enable row level security;

-- Everyone can read dupes and votes. Signed-in visitors (including anonymous) write only their own rows.
create policy "read dupes" on public.dupes for select using (true);
create policy "add dupes" on public.dupes for insert to authenticated with check (created_by = auth.uid());

create policy "read dupe votes" on public.dupe_votes for select using (true);
create policy "add dupe vote" on public.dupe_votes for insert to authenticated with check (user_id = auth.uid());
create policy "change dupe vote" on public.dupe_votes for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "read shade votes" on public.shade_votes for select using (true);
create policy "add shade vote" on public.shade_votes for insert to authenticated with check (user_id = auth.uid());
create policy "change shade vote" on public.shade_votes for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Reports are write-only for visitors. Read them in the Supabase Table Editor.
create policy "send report" on public.shade_reports for insert to authenticated with check (created_by = auth.uid());

create or replace view public.dupe_scores with (security_invoker = true) as
select d.id, d.line_id, d.shade_code, d.brand, d.product, d.shade, d.created_at,
       count(*) filter (where v.value = 1)::int as up,
       count(*) filter (where v.value = -1)::int as down,
       coalesce(sum(v.value), 0)::int as net
from public.dupes d
left join public.dupe_votes v on v.dupe_id = d.id
group by d.id;

create or replace view public.shade_consensus with (security_invoker = true) as
select line_id, shade_code, count(*)::int as n,
       round(avg(depth)::numeric, 1) as depth,
       mode() within group (order by undertone) as undertone
from public.shade_votes
group by line_id, shade_code;

grant select on public.dupe_scores, public.shade_consensus to anon, authenticated;
